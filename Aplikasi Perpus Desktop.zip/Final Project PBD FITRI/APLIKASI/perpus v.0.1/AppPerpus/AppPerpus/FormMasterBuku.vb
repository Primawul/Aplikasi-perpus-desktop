﻿Imports System.Data.SqlClient
Public Class FormMasterBuku
    Sub KondisiAwal()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        ComboBox1.Text = ""
        TextBox6.Text = ""

        'ComboBox1.Items.Add("2018")'
        'ComboBox1.Items.Add("2019")'

        'For i = DateTime.Now.Year - 5 To DateTime.Now.Year
        'ComboBox1.Items.Add(i)
        'Next

        Dim Tahun As String
        Tahun = Date.Now().Year
        ComboBox1.Items.Clear()
        With ComboBox1
            While Tahun >= 2016
                .Items.Add(Tahun)
                Tahun = Tahun - 1
            End While
        End With

        Call Koneksi()
        Da = New SqlDataAdapter("select * from TB_Buku", Conn)
        Ds = New DataSet
        Da.Fill(Ds, "TB_Buku")
        DataGridView1.DataSource = (Ds.Tables("TB_Buku"))

    End Sub

    Private Sub FormMasterBuku_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call KondisiAwal()
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or ComboBox1.Text = "" Or TextBox6.Text = "" Then
            MsgBox("Pastikan Semua Data Terisi")
        Else
            Call Koneksi()
            Dim SimpanData As String = "insert into TB_BUKU values('" & TextBox1.Text & "','" & TextBox2.Text & "','" & TextBox3.Text & "','" & TextBox4.Text & "','" & ComboBox1.Text & "','" & TextBox6.Text & "')"
            Cmd = New SqlCommand(SimpanData, Conn)
            Cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Disimpan")
            Call KondisiAwal()
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or ComboBox1.Text = "" Or TextBox6.Text = "" Then
            MsgBox("Pastikan Semua Data Terisi")
        Else
            Call Koneksi()
            Dim EditData As String = "update TB_BUKU set JudulBuku='" & TextBox2.Text & "',PengarangBuku='" & TextBox3.Text & "',PenerbitBuku='" & TextBox4.Text & "',TahunBuku='" & ComboBox1.Text & "',JumlahBuku='" & TextBox6.Text & "' where KodeBuku='" & TextBox1.Text & "'"
            Cmd = New SqlCommand(EditData, Conn)
            Cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Edit")
            Call KondisiAwal()
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Or TextBox4.Text = "" Or ComboBox1.Text = "" Or TextBox6.Text = "" Then
            MsgBox("Pastikan Semua Data Terisi")
        Else
            Call Koneksi()
            Dim HapusData As String = "Delete TB_BUKU where KodeBuku='" & TextBox1.Text & "'"
            Cmd = New SqlCommand(HapusData, Conn)
            Cmd.ExecuteNonQuery()
            MsgBox("Data Berhasil Hapus")
            Call KondisiAwal()
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub TextBox1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) Then
            Call Koneksi()
            Cmd = New SqlCommand("select * from TB_BUKU where kodeBuku='" & TextBox1.Text & "'", Conn)
            Rd = Cmd.ExecuteReader
            Rd.Read()
            If Rd.HasRows Then
                TextBox2.Text = Rd.Item("JudulBuku")
                TextBox3.Text = Rd.Item("PengarangBuku")
                TextBox4.Text = Rd.Item("PenerbitBuku")
                ComboBox1.Text = Rd.Item("TahunBuku")
                TextBox6.Text = Rd.Item("JumlahBuku")
            Else
                MsgBox("Data Tidak Ada")
            End If
        End If
    End Sub
End Class

